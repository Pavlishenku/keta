@echo off
rem keta graphique, portable: the program and the Qt libraries are in bin\
start "" "%~dp0bin\keta_graphique.exe" %*
